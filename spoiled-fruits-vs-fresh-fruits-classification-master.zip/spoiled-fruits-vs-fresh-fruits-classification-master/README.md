# spoiled-fruits-vs-fresh-fruits-classification

Classifying fresh and rotten fruits for helping stores and farmers to replace them as soon as possible to control the spread

built using tensorflow and cnn with a large data set from kaggle 

for test results and more understanding see TEST RESULTS.PPTX file
